# LiquidCrystal_I2C2004V1
Arduino code to utilize SainSmart 20x4 I2C Yellow LCD Screen (SKU 20-011-931) described here:

http://www.sainsmart.com/sainsmart-iic-i2c-twi-serial-2004-20x4-yellow-lcd-module-shield-for-arduino-uno-mega-r3.html

Unit used by example code here is at address 0x27, rather than 0x3F as described on above page. SKU matches above page's item SKU.

Code source:

http://arduino-info.wikispaces.com/file/detail/LiquidCrystal_I2C2004V1.zip/341635418
